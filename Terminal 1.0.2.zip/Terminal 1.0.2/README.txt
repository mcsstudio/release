1.0.1: Firt version of terminal
1.0.2: What news:
       New commands
       Auto update (--update keep)