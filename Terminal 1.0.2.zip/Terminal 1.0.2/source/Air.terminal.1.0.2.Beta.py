import os, sys, time, json, shutil, random, ctypes, subprocess, requests, math, psutil, zlib, tempfile, platform
from colorama import init, Fore, Style
from pathlib import Path
from dotenv import load_dotenv
import google.generativeai as genai
CURRENT_VERSION = "1.0.3"
UPDATE_JSON_URL = "https://raw.githubusercontent.com/mcsstudio/main/main/update_info.json"
os.system("title Terminal 1.0.2")
init(autoreset=True)

# Xác định thư mục hiện tại của file terminal và đường dẫn JSON mới
current_dir = Path(__file__).resolve().parent
json_dir = current_dir / "json" if (current_dir / "json").exists() else current_dir / "source" / "json"

option_path = json_dir / "option.json"
lang_path = json_dir / "lang.json"
pass_path = current_dir / "pass.txt"

def resource_path(relative_path):
    """Trả về đường dẫn tuyệt đối, dùng được khi đóng gói exe."""
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.abspath("."), relative_path)

# Dùng như sau:
option_path = os.path.join(current_dir, "source", "json", "option.json")

def check_update():
    try:
        response = requests.get(UPDATE_JSON_URL, timeout=10)
        if response.status_code == 200:
            data = response.json()
            latest = data['latest_version']
            if latest != CURRENT_VERSION:
                print(f"\n\033[93m[New update] Version {latest} is avaible")
                print(f"Change: \n{data['changelog']}")
                print(f"Download at: {data['download_url']}\033[0m\n")
        else:
            print("Can't check for updates. Server returned status code (ERR01):", response.status_code)
    except Exception as e:
        print(f"Error in update (ERR02): {e}")

import json
CONFIG_PATH = "option.json"
LANG_PATH = "lang.json"



def load_config():
    try:
        with open(option_path, "r", encoding="utf-8") as f:
            config = json.load(f)
        return config
    except FileNotFoundError:
        print(f"{RED}Can't found option.json (ERRjson01), create new.{RESET}")
        default = {
            "pin": "0000",
            "version": CURRENT_VERSION,
            "auto_update": True,
            "allow_create_account": True,
            "theme": "dark",
            "max_login_attempts": 5,
            "server_status_url": UPDATE_JSON_URL,
            "locked": False
        }
        with open(option_path, "w", encoding="utf-8") as f:
            json.dump(default, f, indent=4)
        return default
    except Exception as e:
        print(f"{RED}Error option.json (ERRjson02a): {e}{RESET}")
        sys.exit()

def load_lang():
    try:
        with open(lang_path, "r", encoding="utf-8") as f:
            configlang = json.load(f)
        return configlang
    except FileNotFoundError:
        print(f"{RED}Can't found lang.json (ERRjson02), create new.{RESET}")
        defaultlang = {"lang": "en-US"}
        with open(lang_path, "w", encoding="utf-8") as f:
            json.dump(defaultlang, f, indent=4)
        return defaultlang
    except Exception as e:
        print(f"{RED}Error lang.json (ERRjson02a): {e}{RESET}")
        sys.exit()



def run_benchmark():
    print(f"{RED}Running benchmark... Please wait...{RESET}")
    def get_system_info():
        print(f"{RED}System Information:{RESET}")
    get_system_info()

    # OS info
    os_name = platform.system()
    os_version = platform.version()
    os_release = platform.release()
    arch = platform.machine()
    print(f"{GREEN}[OS]{RESET} {os_name} {os_release} (Build {os_version}) - {arch}")

    # GPU info (Windows only)
    if os_name == "Windows":
        try:
            output = subprocess.check_output("wmic path win32_VideoController get name", shell=True)
            lines = output.decode(errors='ignore').split('\n')[1:]
            gpus = [line.strip() for line in lines if line.strip()]
            for idx, gpu in enumerate(gpus):
                print(f"{GREEN}[GPU {idx+1}]{RESET} {gpu}")
        except Exception as e:
            print(f"{RED}[GPU]{RESET} Unable to detect GPU: {e}")
    else:
        print(f"{RED}[GPU]{RESET} GPU detection not supported on this OS.")
    
    # CPU test
    start = time.time()
    result = 0
    for i in range(1, 1000000):
        result += math.sqrt(i) * math.sin(i)
    end = time.time()
    score_cpu = 1000000 / (end - start)
    print(f"{GREEN}[CPU]{RESET} {score_cpu:.2f} score")

    # RAM test
    start = time.time()
    big_list = [random.random() for _ in range(10**7)]
    _ = sum(big_list)
    end = time.time()
    score_mem = len(big_list) / (end - start)
    print(f"{GREEN}[RAM]{RESET} {score_mem:.2f} score")

    # Disk I/O
    data = os.urandom(1024 * 1024 * 100)  # 100MB
    tmpfile = tempfile.NamedTemporaryFile(delete=False)
    start = time.time()
    tmpfile.write(data)
    tmpfile.close()
    mid = time.time()
    with open(tmpfile.name, 'rb') as f:
        _ = f.read()
    end = time.time()
    os.remove(tmpfile.name)
    score_disk = (100 / (mid - start) + 100 / (end - mid)) / 2
    print(f"{GREEN}[Disk]{RESET} {score_disk:.2f} MB/s")

    # Compress
    data = os.urandom(1024 * 1024 * 50)
    start = time.time()
    compressed = zlib.compress(data)
    decompressed = zlib.decompress(compressed)
    end = time.time()
    score_cmp = len(data) / (end - start) / (1024 * 1024)
    print(f"{GREEN}[Compress]{RESET} {score_cmp:.2f} MB/s")

    # JSON test
    obj = [{"a": random.randint(0, 1000), "b": random.random()} for _ in range(100000)]
    start = time.time()
    s = json.dumps(obj)
    obj2 = json.loads(s)
    end = time.time()
    score_json = len(s) / (end - start) / 1024
    print(f"{GREEN}[JSON]{RESET} {score_json:.2f} KB/s")

    # Tổng điểm
    total = (score_cpu + score_mem + score_disk + score_cmp + score_json) / 5 *100
    print(f"\n{YELLOW}Benchmark completed.{RESET}")
    print(f"{MAGENTA}Total Benchmark Score: {total:.2f}{RESET}")
    input("Press Enter to return to terminal...")
    terminal()


# ========== ANSI COLOR ==========
GREEN = '\033[92m'
CYAN = '\033[96m'
YELLOW = '\033[93m'
RED = '\033[91m'
MAGENTA = '\033[95m'
RESET = '\033[0m'

# ========== HACKER EFFECT ==========
def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

# ========== TIỆN ÍCH ==========
def loading_bar(percent, total=30):
    filled = int(percent * total)
    empty = total - filled
    bar = '=' * filled + '-' * empty
    print(f"Status: [{bar}] {int(percent * 100)}%", end='\r')

# ========== FAKE HACK ==========
def fake_hack():
    print(f"{MAGENTA}Initializing Hackmode v1.0...{RESET}")
    time.sleep(1)
    steps = [
        "Establishing secure tunnel to mcs.hub.net...",
        "Encrypting connection using RSA-4096...",
        "Injecting bypass payload...",
        "Firewall breached.",
        "Locating entrypoint in system.core...",
        "Access granted. Control level: ROOT",
        "Injecting terminal virus...",
        "Planting backdoor in /brain/sys32...",
        "Spawning AI worm.exe...",
        "Transferring 2048-bit mind control signal...",
        "Hack complete. System compromised."
    ]
    for step in steps:
        print(f"{GREEN}{step}{RESET}")
        time.sleep(0.6)

    print(f"\n{RED}>>> MCS Studio System: You now control the terminal \U0001f608{RESET}")
    input("\nPress Enter to continue...")
    clear()
    terminal()

#Locking the terminal
def lock_terminal():
    print(f"{Fore.RED}Terminal is locked. Enter PIN to unlock.{Style.RESET_ALL}")
    command = int(input(">>> "))
    if command == 0000:
        print(f"{Fore.GREEN}Welcome")
        terminal()
    elif command == "--help":
        print("You can't change PIN in here. [Y] to reset.")
        command = input(">>> ")
        if command == 0000:
            print(f"{Fore.GREEN}Welcome")
            terminal()
        elif command == "y":
            print("PIN can save as 0000 or 1234")
            os.system("pause")
            lock_terminal
    else:
        print(f"{Fore.RED}Wrong PIN, please try again.")
        os.system('cls' if os.name == 'nt' else 'clear')
        lock_terminal()

# ========== TERMINAL ==========
def terminal():
    clear()
    print(f"{CYAN}Terminal 1.0.2 - MCS Studio | Type '--help' for commands{RESET}")
    a = input(">>> ").lower()

    if a == "download --service":
        print(f"{GREEN}Downloading...{RESET}")
        time.sleep(0.3)
        print("Detected MCS Studio services")
        time.sleep(0.3)
        print("MCS Studio Copyright 2025.")
        time.sleep(0.5)
        print("Waiting from server...")
        time.sleep(0.75)
        print("Collecting data...")
        time.sleep(0.25)
        print("File detected")
        time.sleep(0.5)
        print("Downloading...")

        for i in range(31):
            percent = i / 30
            loading_bar(percent)
            if i == 29:
                time.sleep(10)
            else:
                time.sleep(0.1)
        print()
        print(f"{GREEN}Download completed successfully.{RESET}")
        time.sleep(0.5)
        again = input("Do you want to download again? [Y/N]: ").lower()
        if again == 'y':
            terminal()
        else:
            print("Exiting... See you soon!")
            time.sleep(0.5)
            sys.exit()

    elif a == "--exit":
        print(f"{YELLOW}Exiting terminal...{RESET}")
        time.sleep(0.5)
        sys.exit()

    elif a == "--benchmark":
        run_benchmark()
        
    elif a == "--debug":
        print(f"{MAGENTA}DEBUG MODE INITIATED...{RESET}")
        time.sleep(0.3)
        print("Running system check...")
        time.sleep(0.5)
        print("Analyzing memory...")
        time.sleep(0.5)
        print("Memory status: OK")
        print("Terminal log saved to debug.log")
        time.sleep(1)
        input("Press Enter to continue...")
        terminal()

    elif a == "--help":
        print(f"  {YELLOW}Available Commands:{RESET}")
        print(f"  {GREEN}download --service{RESET}      : Download service")
        print(f"  {GREEN}--update [remove/keep]{RESET}  : Update version")
        print(f"  {RED}--debug{RESET}                   : Enter debug mode")
        print(f"  {RED}--destroy{RESET}                 : system wipe")
        print(f"  {RED}--hackmode.net | mcs{RESET}      : Initiate hack mode")
        print(f"  {RED}--duplicate{RESET}               : Duplicate terminal")
        print(f"  {RED}--dev_tool: r/ d/ f/ all         : Dangerus Command")
        print(f"  {RED}--?????????{RESET}               : ????????? terminal")
        print(f"  {CYAN}--changepass{RESET}             : PIN change")
        print(f"  {CYAN}--exit{RESET}                   : Exit the terminal")
        print(f"  {CYAN}--benchmark{RESET}              : Benchmark test")
        input("\nPress Enter to return...")
        terminal()

    elif a == "--destroy":
        print(f"{RED}WARNING: Irreversible neural destruction initiated...{RESET}")
        time.sleep(0.5)
        print("Shutting down visual cortex...")
        time.sleep(1)
        print("Overloading hippocampus...")
        time.sleep(1.5)
        print(f"{RED}BOOM \U0001f4a5 system32 has stopped responding.{RESET}")
        time.sleep(1)
        input("Press Enter to reboot consciousness...")
        terminal()

    elif a == "--hackmode.net | mcs":
        fake_hack()

    elif a == "--bsod":
        clear()
        print("\033[1;37;44m")
        print("A problem has been detected and Windows has been shut down to prevent damage")
        print("to your computer.\n")
        print("The problem seems to be caused by the following file: MCS_TERMINAL.SYS\n")
        print("PAGE_FAULT_IN_NONPAGED_AREA\n")
        print("If this is the first time you've seen this Stop error screen,")
        print("restart your computer. If this screen appears again, follow")
        print("these steps:\n")
        print("- Check to make sure any new hardware or software is properly installed.")
        print("- If this is a new installation, ask your hardware or software manufacturer")
        print("  for any Windows updates you might need.\n")
        print("Technical Information:")
        print("*** STOP: 0x00000050 (0xFFFFF880009AA000, 0x0000000000000000,")
        print("              0xFFFFF80002ED53F7, 0x0000000000000000)\n")
        print("Collecting data for crash dump ...")
        print("Initializing disk for crash dump ...")
        print("Beginning dump of physical memory.\n")
        print("Dumping physical memory to disk: 100")
        print("Press Enter to simulate reboot...", end='')
        input()
        terminal()
    elif a == "--duplicate":
        os.system("title Termiinal.duplicate")
        exit
        lock_terminal()

    elif a == "--easteregg":
        print(f"{YELLOW}Easter Egg Terminal Activated!{RESET}")
        time.sleep(0.5)
        print("Welcome to the Easter Egg terminal!")
        print("This terminal is full of surprises and fun commands.")
        print("Type 'surprise' to see a random surprise!")
        while True:
            surprise = input(">>> ").lower()
            if surprise == "surprise":
                surprises = [
                    "🎉 Surprise! You found a hidden message!",
                    "🐱 Here's a cute cat picture: [cat image]",
                    "🎈 You win a balloon! 🎈",
                    "💻 Hacking into the mainframe... Just kidding, it's all fake!"
                ]
                print(random.choice(surprises))
            else:
                print(f"{RED}Unknown command in Easter Egg terminal (ERR004){RESET}")

    elif a == "--dev_tool: wipedata":
        print("Dev Tool: Wiping data...")
        time.sleep(0.5)
        print("Are you sure you want to wipe all data? This action cannot be undone.")
        confirm = input("Type 'yes' to confirm: ").lower()
        if confirm == 'yes':
            print("Wiping data...")
            time.sleep(1)
            print("Data wiped successfully. Terminal is now empty.")
            time.sleep(1)
            print("Exiting terminal...")
            sys.exit()
        else:
            print("Data wipe cancelled.")
            time.sleep(1)
            terminal()

    elif a == "--dev_tool: r/ d/ f/ all":
        print("Are you sure to use this command? That a hard command. (R/ = Reset, D/ = Delete, F/ = Format, All = all partitions of terminal), delete all temporary data and disable all lisenses keys. (Y/N)")
        confirm = input(">>> ").lower()
        if confirm == 'y':
            print("Resetting terminal...")
            time.sleep(1)
            print("Deleting temporary files...")
            time.sleep(1)
            print("Formatting all partitions...")
            time.sleep(1)
            print("Disabling all license keys...")
            print("Reset key to trial key.")
            time.sleep(1)

            try:
                with open("pass.txt", "w") as f:
                    f.write("0000")
                print("PIN has been reset to: 0000")
            except Exception as e:
                print(f"{RED}Error in PIN reset (ERR03): {e}{RESET}")

            print("All data has been reset. Terminal is now clean.")
            time.sleep(1)
            print("Exiting terminal...")
            sys.exit()
        else:
            print("Operation cancelled (ERR05). Returning to terminal.")
            time.sleep(1)
            terminal()

    elif a == "--check_version":
        print(f"Version {CURRENT_VERSION} is currently installed.")

    elif a == "--lock":
        lock_terminal()

    elif a == "--changepass":
        try:
            with open("pass.txt", "r") as f:
                current_pass = f.read().strip()
        except FileNotFoundError:
            print(f"{RED}Can't found pass.txt (ERR06),create new file {RESET}")
            current_pass = "0000"

        entered_old = input("Enter PIN: ").strip()
        if entered_old != current_pass:
            print(f"{RED}Wrong now pass, can't change (ERR007){RESET}")
            time.sleep(1)
            terminal()

        new_pass = input("Enter new PIN (4 characts): ").strip()
        if len(new_pass) != 4 or not new_pass.isdigit():
            print(f"{RED}PIN not valid, try again (ERR08).{RESET}")
            time.sleep(1)
            terminal()
        with open("pass.txt", "w") as f:
            f.write(new_pass)

        print(f"{GREEN}PIN has been update.{RESET}")
        time.sleep(1)
        terminal()

    elif a.startswith("--print [") and a.endswith("]"):
        content = a[9:-1]  # Cắt phần ["..."]
        if content.startswith('"') and content.endswith('"'):
            print(content[1:-1])  # Bỏ dấu nháy kép
        elif content.startswith("'") and content.endswith("'"):
                print(content[1:-1])  # Bỏ dấu nháy đơn
        else:
                print(content)
        time.sleep(1)
        terminal()

    elif a == "--dev_tool: IDLE":
        print(f"{RED}IDE Is not support in 1.0.2 Terminal (ERRextion01)")
        run = input("Press [Y] to return.")
        if run == "Y":
            terminal()
        else:
            terminal()
    
    elif a.startswith("--update"):
        try:
            response = requests.get(UPDATE_JSON_URL, timeout=3)
            if response.status_code == 200:
                data = response.json()
                latest = data['latest_version']
                if latest != CURRENT_VERSION:
                    print(f"{YELLOW}New version {latest} available!{RESET}")
                    print(f"Changelog:\n{data['changelog']}")
                    print(f"Download from: {data['download_url']}")
                    
                    keep_old = a.strip() == "--update keep"
                    remove_old = a.strip() == "--update remove"

                    if not (keep_old or remove_old):
                        print(f"{RED}Invalid update option. Use '--update keep' or '--update remove'{RESET}")
                        terminal()
                        return
                    
                    filename = f"Air_terminal_{latest}.py"
                    print(f"Downloading update as '{filename}'...")
                    download_url = data['download_url']
                    
                    filedata = requests.get(download_url, timeout=5)
                    with open(filename, "wb") as f:
                        f.write(filedata.content)
                    
                    print(f"{GREEN}Download complete.{RESET}")
                    
                    if remove_old:
                        print("Removing old version...")
                        old_file = sys.argv[0]
                        with open("updater.bat", "w") as f:
                            f.write(f"""@echo off
                        timeout /t 2 >nul
                        del "{old_file}"
                        start "" "{filename}"
                        del updater.bat
                        """)
                        os.startfile("updater.bat")
                        sys.exit()
                    else:
                        print(f"Update saved as: {filename} (old version kept)")
                        time.sleep(1)
                        terminal()
                else:
                    print("You're already using the latest version.")
                    time.sleep(1)
                    terminal()
            else:
                print("Update check failed. (ERR11)")
                terminal()
        except Exception as e:
            print(f"{RED}Error in update: {e}{RESET}")
            terminal()

    else:
        print(f"{RED}Unknown command (ERR09): '{a}' — try '--help'{RESET}")
        time.sleep(1)
        terminal()


if __name__ == '__main__':
    check_update()
    config = load_config()
    lang = load_lang()

    lock_terminal()